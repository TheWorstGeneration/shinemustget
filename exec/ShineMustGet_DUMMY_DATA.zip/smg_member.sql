-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.78.90.69    Database: smg
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `kakao_id` varchar(255) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `social_type` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `special_sticker_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`kakao_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('2762527385','http://k.kakaocdn.net/dn/czxNxJ/btseIGmp7d4/vwk45zCOKkzUjD5LCEKK00/img_110x110.jpg','최동호',NULL,'KAKAO','USER',NULL),('2762543073','http://k.kakaocdn.net/dn/bOnBkF/btsdPAVaCvf/9th8KB5ihUkiYOjlrYob31/img_110x110.jpg','박윤지',NULL,'KAKAO','USER','2023-05-11 13:26:58.447803'),('2765410035','http://k.kakaocdn.net/dn/bvipsX/btrUukYJQL5/FpKv3THjvgozqwFz2Jij51/img_110x110.jpg','김민식',NULL,'KAKAO','USER',NULL),('2765558388','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','임성빈',NULL,'KAKAO','USER',NULL),('2765572513','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','조재형',NULL,'KAKAO','USER',NULL),('2767014880','http://k.kakaocdn.net/dn/zPcK6/btsd6sPExRs/obOjwfIxEQHbPKCfLyzWX1/img_110x110.jpg','김영주',NULL,'KAKAO','USER',NULL),('2778314136','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','성중',NULL,'KAKAO','GUEST',NULL),('2780428857','http://k.kakaocdn.net/dn/bZJD2y/btr01UYE8rk/QQwWMvxRkMXcUOimWacwXk/img_110x110.jpg','성유지',NULL,'KAKAO','USER',NULL),('2785645940','http://k.kakaocdn.net/dn/bnL3jF/btscGUOmIHP/rH5z4VOvtEPJKU7oDshf21/img_110x110.jpg','용현',NULL,'KAKAO','GUEST',NULL),('2786060990','http://k.kakaocdn.net/dn/bqjtIJ/btr22Ktl2qV/mMHlKAbXkUxxUDoRy1mKZ0/img_110x110.jpg','오태훈',NULL,'KAKAO','GUEST',NULL),('2786064558','http://k.kakaocdn.net/dn/uiJqy/btrRAiPYhbo/RXrH9YKIQ099Kp09HlTMuk/img_110x110.jpg','이상구',NULL,'KAKAO','GUEST',NULL),('2786066355','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','희제',NULL,'KAKAO','GUEST',NULL),('2786768144','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_110x110.jpg','신아랑',NULL,'KAKAO','GUEST',NULL),('2790722964','http://k.kakaocdn.net/dn/kU3rw/btrwqMCUiPI/2PVkFw63E2fkiUxxeE9dS1/img_110x110.jpg','최현호',NULL,'KAKAO','USER',NULL),('2790734056','http://k.kakaocdn.net/dn/rIRT4/btrQpyeeUTm/l8mMPXjBxoy1mSbPfUmVu0/img_110x110.jpg','고성현',NULL,'KAKAO','USER',NULL),('2791193667','http://k.kakaocdn.net/dn/1x5S1/btr7xV44LjT/CXsOVkPO5YNDCTkDvims0k/img_110x110.jpg','유주영',NULL,'KAKAO','USER',NULL),('29','가짜유저','가짜유저',NULL,'KAKAO','USER',NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-17 12:54:11
