-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 52.78.90.69    Database: smg
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `likes` (
  `likes_id` int NOT NULL AUTO_INCREMENT,
  `status` bit(1) NOT NULL,
  `kakao_id` varchar(255) DEFAULT NULL,
  `title_id` int DEFAULT NULL,
  PRIMARY KEY (`likes_id`),
  KEY `FKea8c3syrdtqttx0i9hxibnbdo` (`kakao_id`),
  KEY `FKevphgxd9vpw3klg5uerobww4g` (`title_id`),
  CONSTRAINT `FKea8c3syrdtqttx0i9hxibnbdo` FOREIGN KEY (`kakao_id`) REFERENCES `member` (`kakao_id`),
  CONSTRAINT `FKevphgxd9vpw3klg5uerobww4g` FOREIGN KEY (`title_id`) REFERENCES `title` (`title_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (6,_binary '','2762527385',8),(7,_binary '\0','2762543073',8),(8,_binary '\0','2762527385',7),(9,_binary '','2762543073',7),(10,_binary '\0','2762543073',5),(11,_binary '','2762527385',5),(12,_binary '\0','2762543073',6),(13,_binary '\0','2765572513',94),(14,_binary '','2762543073',94),(15,_binary '\0','2765572513',95),(16,_binary '','2765572513',103),(17,_binary '','2765572513',106),(18,_binary '','2765572513',122),(19,_binary '','2762543073',122),(20,_binary '\0','2765572513',7),(21,_binary '','2765572513',101),(22,_binary '','2767014880',100),(23,_binary '','2765572513',102),(24,_binary '','2767014880',123),(25,_binary '','2765572513',8),(26,_binary '','2765572513',123),(27,_binary '','2767014880',124),(28,_binary '','2767014880',106),(29,_binary '','2765572513',124),(30,_binary '','2765572513',111),(31,_binary '','2765572513',100),(32,_binary '','2765558388',122),(33,_binary '','2765558388',122),(34,_binary '','2762527385',122),(35,_binary '','2765410035',122),(36,_binary '','2765410035',156),(38,_binary '','2765410035',158),(39,_binary '','2765410035',100),(40,_binary '','2765558388',123);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-17 12:54:11
